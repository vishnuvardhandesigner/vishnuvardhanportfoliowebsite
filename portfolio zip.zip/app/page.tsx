"use client"

import { useEffect, useRef, useState } from "react"
import Navbar from "@/components/navbar"
import Hero from "@/components/hero"
import About from "@/components/about"
import Skills from "@/components/skills"
import Portfolio from "@/components/portfolio"
import Process from "@/components/process"
import Testimonials from "@/components/testimonials"
import Contact from "@/components/contact"
import Footer from "@/components/footer"
import MobileDrawer from "@/components/mobile-drawer"
import Marquee from "@/components/marquee"
import CustomCursor from "@/components/custom-cursor"

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <>
      <CustomCursor />
      <MobileDrawer isOpen={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} />
      <div id="top"></div>
      <Marquee />
      <Navbar onMenuClick={() => setMobileMenuOpen(true)} />
      <Hero />
      <About />
      <Skills />
      <Portfolio />
      <Process />
      <Testimonials />
      <Contact />
      <Footer />
    </>
  )
}
