import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Logos for Startups | Brand Identity",
  description: "Complete brand identity design for startups including logo design, color palettes, typography, and brand applications across various touchpoints.",
}

const logoProjects = [
  {
    name: "Dhaba @Blooming Farms",
    description: "A rustic farm-to-table restaurant brand identity featuring traditional Indian food truck aesthetics with a modern twist. The design incorporates a chef hat, utensils, and a vibrant food illustration.",
    colors: ["#38631C", "#F9C322", "#FFFFFF"],
    image: "/portfolio/logos/dhaba-branding.jpg",
  },
  {
    name: "Creatiwise",
    description: "A tech-forward creative agency brand featuring a clever moon and brain combination logo. The minimal black and white palette works seamlessly across dark and light modes with Manrope typography.",
    colors: ["#000000", "#2A2929", "#FCFCFD", "#1E1E1E", "#FFFFFF"],
    image: "/portfolio/logos/creatiwise-branding.jpg",
  },
  {
    name: "Swaruchi Foods",
    description: "Homemade Indian snacks brand identity with warm, appetizing colors. The logo features traditional snacks in a decorative pot with elegant typography, applied across uniforms, food trucks, and packaging.",
    colors: ["#D35400", "#F9A825", "#558B2F"],
    image: "/portfolio/logos/swaruchi-branding.jpg",
  },
  {
    name: "Short Films & Comedy",
    description: "A playful YouTube channel brand featuring a 3D-style logo with clapperboard, popcorn, and film reel elements. The vibrant color palette and Nunito Bold typography create an engaging entertainment feel.",
    colors: ["#F5A623", "#EE3224", "#39C5D5", "#F9F5DF"],
    image: "/portfolio/logos/sc-branding.png",
  },
]

export default function LogosForStartupsPage() {
  return (
    <div className="project-detail-page">
      {/* Header */}
      <header className="project-header">
        <Link href="/#portfolio" className="back-btn">
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          Back to Works
        </Link>

        <div className="project-title-section">
          <div className="project-category">Brand Identity</div>
          <h1 className="project-title">Logos for Startups</h1>
          <p className="project-description">
            A collection of complete brand identity designs for diverse startups, ranging from food businesses to tech agencies and entertainment channels. Each project includes logo design, color palettes, typography systems, and real-world brand applications.
          </p>
        </div>
      </header>

      {/* Project Details */}
      <section className="project-details">
        <div className="detail-grid">
          <div className="detail-item">
            <span className="detail-label">Category</span>
            <span className="detail-value">Brand Identity</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Deliverables</span>
            <span className="detail-value">Logo, Colors, Typography</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Tools</span>
            <span className="detail-value">Illustrator, Photoshop</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Projects</span>
            <span className="detail-value">4 Brands</span>
          </div>
        </div>
      </section>

      {/* Logo Projects Gallery */}
      <section className="logos-gallery-section">
        <h2>Brand Identity Projects</h2>
        <p className="section-description">
          Each brand identity is crafted with attention to the client&apos;s unique story, target audience, and industry requirements.
        </p>

        <div className="logos-gallery">
          {logoProjects.map((project, index) => (
            <div key={index} className="logo-project-card">
              <div className="logo-project-image-wrap">
                <img
                  src={project.image}
                  alt={`${project.name} brand identity sheet`}
                  className="logo-project-image"
                />
              </div>
              <div className="logo-project-info">
                <h3>{project.name}</h3>
                <p>{project.description}</p>
                <div className="logo-project-colors">
                  <span className="colors-label">Color Palette:</span>
                  <div className="color-swatches">
                    {project.colors.map((color, i) => (
                      <div
                        key={i}
                        className="color-swatch"
                        style={{ backgroundColor: color }}
                        title={color}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Process Section */}
      <section className="project-highlights">
        <h2>Design Process</h2>
        <div className="highlights-grid">
          <div className="highlight-card">
            <div className="highlight-number">01</div>
            <h3>Discovery</h3>
            <p>Understanding the brand story, target audience, and competitive landscape through research and client interviews.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">02</div>
            <h3>Concept Development</h3>
            <p>Creating multiple logo concepts exploring different visual directions and typography treatments.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">03</div>
            <h3>Refinement</h3>
            <p>Iterating on the chosen direction, perfecting proportions, colors, and establishing the visual system.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">04</div>
            <h3>Brand Applications</h3>
            <p>Applying the identity across touchpoints including stationery, signage, packaging, and digital platforms.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="project-footer">
        <Link href="/#portfolio" className="back-btn-large">
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          Back to Works
        </Link>
      </footer>
    </div>
  )
}
