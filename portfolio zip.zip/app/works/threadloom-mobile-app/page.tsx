import Link from "next/link"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Threadloom Mobile App | UI/UX Design",
  description: "A premium fashion e-commerce mobile app featuring curated editorial shopping, seamless checkout, and community reviews.",
}

const screens = [
  {
    image: "/portfolio/threadloom/home.jpg",
    title: "Home & Discovery",
    description: "Hero editorial imagery with \"Fashion That Speaks\" campaign, curated product collections, and category navigation for Women, Men, and Accessories.",
  },
  {
    image: "/portfolio/threadloom/add-to-cart.jpg",
    title: "Product Details",
    description: "Clean product presentation with color/size selectors, pricing with discounts, expandable details sections, and \"Complete the Look\" recommendations.",
  },
  {
    image: "/portfolio/threadloom/checkout.jpg",
    title: "Cart & Checkout",
    description: "Curated selection view with item management, complimentary shipping, clear pricing breakdown, and smart product suggestions.",
  },
  {
    image: "/portfolio/threadloom/review.jpg",
    title: "Community Reviews",
    description: "Customer feedback with 4.8 rating visualization, review submission form, and authentic testimonials from verified buyers.",
  },
]

export default function ThreadloomMobileAppPage() {
  return (
    <div className="project-detail-page">
      {/* Header */}
      <header className="project-header">
        <Link href="/#portfolio" className="back-btn">
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          Back to Works
        </Link>

        <div className="project-title-section">
          <span className="project-category">UI / UX Design</span>
          <h1 className="project-title">Threadloom Mobile App</h1>
          <p className="project-description">
            A premium fashion e-commerce mobile application designed for the modern, 
            conscious shopper. Threadloom emphasizes curation over quantity, featuring 
            editorial-style product presentation, seamless shopping experiences, and 
            authentic community engagement.
          </p>
        </div>
      </header>

      {/* Project Details */}
      <section className="project-details">
        <div className="detail-grid">
          <div className="detail-item">
            <span className="detail-label">Role</span>
            <span className="detail-value">UI/UX Designer</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Timeline</span>
            <span className="detail-value">4 Weeks</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Tools</span>
            <span className="detail-value">Figma, Protopie</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Platform</span>
            <span className="detail-value">iOS & Android</span>
          </div>
        </div>
      </section>

      {/* App Screens Gallery */}
      <section className="threadloom-gallery-section">
        <h2>App Screens</h2>
        <p className="section-description">
          Four key screens showcasing the complete shopping journey from discovery to checkout 
          and community engagement.
        </p>

        <div className="mobile-screens-grid">
          {screens.map((screen, index) => (
            <div key={index} className="mobile-screen-card">
              <div className="mobile-screen-image-wrap">
                <img
                  src={screen.image}
                  alt={`Threadloom ${screen.title} screen`}
                  className="mobile-screen-image"
                />
              </div>
              <div className="mobile-screen-info">
                <h3>{screen.title}</h3>
                <p>{screen.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Design Philosophy */}
      <section className="project-highlights">
        <h2>Design Philosophy</h2>
        <div className="highlights-grid">
          <div className="highlight-card">
            <div className="highlight-number">01</div>
            <h3>Editorial Aesthetics</h3>
            <p>High-fashion imagery and typography inspired by luxury magazines, elevating the mobile shopping experience.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">02</div>
            <h3>Curated Experience</h3>
            <p>Quality over quantity approach with hand-selected products and smart \"Complete the Look\" recommendations.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">03</div>
            <h3>Seamless Commerce</h3>
            <p>Frictionless checkout with clear pricing, complimentary shipping messaging, and intuitive cart management.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">04</div>
            <h3>Community Trust</h3>
            <p>Authentic customer reviews with visual ratings and easy submission to build brand credibility.</p>
          </div>
        </div>
      </section>

      {/* Brand Elements */}
      <section className="brand-elements-section">
        <h2>Brand Elements</h2>
        <div className="brand-grid">
          <div className="brand-element">
            <span className="brand-label">Primary Color</span>
            <div className="brand-color-swatch" style={{ background: "#E67E22" }}></div>
            <span className="brand-value">Burnt Orange #E67E22</span>
          </div>
          <div className="brand-element">
            <span className="brand-label">Typography</span>
            <div className="brand-typography">THREADLOOM</div>
            <span className="brand-value">Spaced Capitals</span>
          </div>
          <div className="brand-element">
            <span className="brand-label">UI Style</span>
            <div className="brand-style-badge">Clean & Minimal</div>
            <span className="brand-value">White backgrounds, clear hierarchy</span>
          </div>
          <div className="brand-element">
            <span className="brand-label">Ethos</span>
            <div className="brand-quote">{'"Curation over quantity"'}</div>
            <span className="brand-value">Quality-first philosophy</span>
          </div>
        </div>
      </section>

      {/* Footer with Back Button */}
      <footer className="project-footer">
        <Link href="/#portfolio" className="back-btn-large">
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          Back to Works
        </Link>
      </footer>
    </div>
  )
}
