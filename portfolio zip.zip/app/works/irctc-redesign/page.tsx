"use client"

import Link from "next/link"

export default function IRCTCRedesignPage() {
  return (
    <div className="project-detail-page">
      <div className="project-header">
        <Link href="/#portfolio" className="back-btn">
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          Back to Works
        </Link>
        <div className="project-title-section">
          <span className="project-category">UI / UX Design</span>
          <h1 className="project-title">IRCTC Redesign — TatkalSwift</h1>
          <p className="project-description">
            A complete redesign of the IRCTC Tatkal booking experience, focusing on speed, 
            efficiency, and user experience. TatkalSwift is engineered for velocity — helping 
            users secure Tatkal tickets with millisecond precision.
          </p>
        </div>
      </div>

      <div className="project-details">
        <div className="detail-grid">
          <div className="detail-item">
            <span className="detail-label">Role</span>
            <span className="detail-value">UI/UX Designer</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Timeline</span>
            <span className="detail-value">4 Weeks</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Tools</span>
            <span className="detail-value">Figma, Photoshop</span>
          </div>
          <div className="detail-item">
            <span className="detail-label">Type</span>
            <span className="detail-value">Case Study</span>
          </div>
        </div>
      </div>

      <div className="project-highlights">
        <h2>Key Features</h2>
        <div className="highlights-grid">
          <div className="highlight-card">
            <div className="highlight-number">01</div>
            <h3>Millisecond Precision</h3>
            <p>Proprietary countdown technology that synchronizes directly with railway servers for exact timing.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">02</div>
            <h3>Smart Auto-fill</h3>
            <p>Pre-save traveler profiles and route preferences with one-click population of passenger data.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">03</div>
            <h3>Instant Payments</h3>
            <p>Direct gateway integration bypasses traditional checkout lag for lightning-fast transactions.</p>
          </div>
          <div className="highlight-card">
            <div className="highlight-number">04</div>
            <h3>Performance Metrics</h3>
            <p>98.4% success rate, 42ms latency, and 1.2M+ tickets secured with 24/7 availability.</p>
          </div>
        </div>
      </div>

      <div className="project-case-study-section">
        <h2>Case Study</h2>
        <p className="pdf-description">
          Explore the complete design process, wireframes, and final UI screens in the detailed case study below.
        </p>
        <div className="case-study-image-container">
          <img 
            src="/portfolio/irctc-case-study.jpg" 
            alt="IRCTC Redesign TatkalSwift - Complete UI/UX Case Study showing hero section, feature highlights, booking interface, payment flow, and confirmation screens"
            className="case-study-image"
          />
        </div>
        <a
          href="/portfolio/irctc-redesign.pdf"
          download="IRCTC-Redesign-TatkalSwift.pdf"
          className="download-btn"
        >
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3" />
          </svg>
          Download Full PDF
        </a>
      </div>

      <div className="project-footer">
        <Link href="/#portfolio" className="back-btn-large">
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M19 12H5M12 19l-7-7 7-7" />
          </svg>
          Back to Works
        </Link>
      </div>
    </div>
  )
}
